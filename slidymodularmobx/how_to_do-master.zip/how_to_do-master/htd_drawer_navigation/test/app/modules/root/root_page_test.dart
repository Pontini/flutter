import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_modular/flutter_modular_test.dart';

import 'package:htd_drawer_navigation/app/modules/root/root_page.dart';

main() {
  testWidgets('RootPage has title', (WidgetTester tester) async {
    await tester.pumpWidget(buildTestableWidget(RootPage(title: 'Root')));
    final titleFinder = find.text('Root');
    expect(titleFinder, findsOneWidget);
  });
}
