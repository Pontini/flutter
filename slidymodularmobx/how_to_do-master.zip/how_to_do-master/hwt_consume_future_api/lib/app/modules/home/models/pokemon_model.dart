
import 'dart:convert';

class PokemonModel {
    final List<Ability> abilities;
    final int baseExperience;
    final List<Species> forms;
    final List<GameIndex> gameIndices;
    final int height;
    final List<dynamic> heldItems;
    final int id;
    final bool isDefault;
    final String locationAreaEncounters;
    final List<Move> moves;
    final String name;
    final int order;
    final Species species;
    final Sprites sprites;
    final List<Stat> stats;
    final List<Type> types;
    final int weight;

    PokemonModel({
        this.abilities,
        this.baseExperience,
        this.forms,
        this.gameIndices,
        this.height,
        this.heldItems,
        this.id,
        this.isDefault,
        this.locationAreaEncounters,
        this.moves,
        this.name,
        this.order,
        this.species,
        this.sprites,
        this.stats,
        this.types,
        this.weight,
    });

    PokemonModel copyWith({
        List<Ability> abilities,
        int baseExperience,
        List<Species> forms,
        List<GameIndex> gameIndices,
        int height,
        List<dynamic> heldItems,
        int id,
        bool isDefault,
        String locationAreaEncounters,
        List<Move> moves,
        String name,
        int order,
        Species species,
        Sprites sprites,
        List<Stat> stats,
        List<Type> types,
        int weight,
    }) => 
        PokemonModel(
            abilities: abilities ?? this.abilities,
            baseExperience: baseExperience ?? this.baseExperience,
            forms: forms ?? this.forms,
            gameIndices: gameIndices ?? this.gameIndices,
            height: height ?? this.height,
            heldItems: heldItems ?? this.heldItems,
            id: id ?? this.id,
            isDefault: isDefault ?? this.isDefault,
            locationAreaEncounters: locationAreaEncounters ?? this.locationAreaEncounters,
            moves: moves ?? this.moves,
            name: name ?? this.name,
            order: order ?? this.order,
            species: species ?? this.species,
            sprites: sprites ?? this.sprites,
            stats: stats ?? this.stats,
            types: types ?? this.types,
            weight: weight ?? this.weight,
        );

    factory PokemonModel.fromJson(String str) => PokemonModel.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory PokemonModel.fromMap(Map<String, dynamic> json) => PokemonModel(
        abilities: List<Ability>.from(json["abilities"].map((x) => Ability.fromMap(x))),
        baseExperience: json["base_experience"],
        forms: List<Species>.from(json["forms"].map((x) => Species.fromMap(x))),
        gameIndices: List<GameIndex>.from(json["game_indices"].map((x) => GameIndex.fromMap(x))),
        height: json["height"],
        heldItems: List<dynamic>.from(json["held_items"].map((x) => x)),
        id: json["id"],
        isDefault: json["is_default"],
        locationAreaEncounters: json["location_area_encounters"],
        moves: List<Move>.from(json["moves"].map((x) => Move.fromMap(x))),
        name: json["name"],
        order: json["order"],
        species: Species.fromMap(json["species"]),
        sprites: Sprites.fromMap(json["sprites"]),
        stats: List<Stat>.from(json["stats"].map((x) => Stat.fromMap(x))),
        types: List<Type>.from(json["types"].map((x) => Type.fromMap(x))),
        weight: json["weight"],
    );

    Map<String, dynamic> toMap() => {
        "abilities": List<dynamic>.from(abilities.map((x) => x.toMap())),
        "base_experience": baseExperience,
        "forms": List<dynamic>.from(forms.map((x) => x.toMap())),
        "game_indices": List<dynamic>.from(gameIndices.map((x) => x.toMap())),
        "height": height,
        "held_items": List<dynamic>.from(heldItems.map((x) => x)),
        "id": id,
        "is_default": isDefault,
        "location_area_encounters": locationAreaEncounters,
        "moves": List<dynamic>.from(moves.map((x) => x.toMap())),
        "name": name,
        "order": order,
        "species": species.toMap(),
        "sprites": sprites.toMap(),
        "stats": List<dynamic>.from(stats.map((x) => x.toMap())),
        "types": List<dynamic>.from(types.map((x) => x.toMap())),
        "weight": weight,
    };
}

class Ability {
    final Species ability;
    final bool isHidden;
    final int slot;

    Ability({
        this.ability,
        this.isHidden,
        this.slot,
    });

    Ability copyWith({
        Species ability,
        bool isHidden,
        int slot,
    }) => 
        Ability(
            ability: ability ?? this.ability,
            isHidden: isHidden ?? this.isHidden,
            slot: slot ?? this.slot,
        );

    factory Ability.fromJson(String str) => Ability.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Ability.fromMap(Map<String, dynamic> json) => Ability(
        ability: Species.fromMap(json["ability"]),
        isHidden: json["is_hidden"],
        slot: json["slot"],
    );

    Map<String, dynamic> toMap() => {
        "ability": ability.toMap(),
        "is_hidden": isHidden,
        "slot": slot,
    };
}

class Species {
    final String name;
    final String url;

    Species({
        this.name,
        this.url,
    });

    Species copyWith({
        String name,
        String url,
    }) => 
        Species(
            name: name ?? this.name,
            url: url ?? this.url,
        );

    factory Species.fromJson(String str) => Species.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Species.fromMap(Map<String, dynamic> json) => Species(
        name: json["name"],
        url: json["url"],
    );

    Map<String, dynamic> toMap() => {
        "name": name,
        "url": url,
    };
}

class GameIndex {
    final int gameIndex;
    final Species version;

    GameIndex({
        this.gameIndex,
        this.version,
    });

    GameIndex copyWith({
        int gameIndex,
        Species version,
    }) => 
        GameIndex(
            gameIndex: gameIndex ?? this.gameIndex,
            version: version ?? this.version,
        );

    factory GameIndex.fromJson(String str) => GameIndex.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory GameIndex.fromMap(Map<String, dynamic> json) => GameIndex(
        gameIndex: json["game_index"],
        version: Species.fromMap(json["version"]),
    );

    Map<String, dynamic> toMap() => {
        "game_index": gameIndex,
        "version": version.toMap(),
    };
}

class Move {
    final Species move;
    final List<VersionGroupDetail> versionGroupDetails;

    Move({
        this.move,
        this.versionGroupDetails,
    });

    Move copyWith({
        Species move,
        List<VersionGroupDetail> versionGroupDetails,
    }) => 
        Move(
            move: move ?? this.move,
            versionGroupDetails: versionGroupDetails ?? this.versionGroupDetails,
        );

    factory Move.fromJson(String str) => Move.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Move.fromMap(Map<String, dynamic> json) => Move(
        move: Species.fromMap(json["move"]),
        versionGroupDetails: List<VersionGroupDetail>.from(json["version_group_details"].map((x) => VersionGroupDetail.fromMap(x))),
    );

    Map<String, dynamic> toMap() => {
        "move": move.toMap(),
        "version_group_details": List<dynamic>.from(versionGroupDetails.map((x) => x.toMap())),
    };
}

class VersionGroupDetail {
    final int levelLearnedAt;
    final Species moveLearnMethod;
    final Species versionGroup;

    VersionGroupDetail({
        this.levelLearnedAt,
        this.moveLearnMethod,
        this.versionGroup,
    });

    VersionGroupDetail copyWith({
        int levelLearnedAt,
        Species moveLearnMethod,
        Species versionGroup,
    }) => 
        VersionGroupDetail(
            levelLearnedAt: levelLearnedAt ?? this.levelLearnedAt,
            moveLearnMethod: moveLearnMethod ?? this.moveLearnMethod,
            versionGroup: versionGroup ?? this.versionGroup,
        );

    factory VersionGroupDetail.fromJson(String str) => VersionGroupDetail.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory VersionGroupDetail.fromMap(Map<String, dynamic> json) => VersionGroupDetail(
        levelLearnedAt: json["level_learned_at"],
        moveLearnMethod: Species.fromMap(json["move_learn_method"]),
        versionGroup: Species.fromMap(json["version_group"]),
    );

    Map<String, dynamic> toMap() => {
        "level_learned_at": levelLearnedAt,
        "move_learn_method": moveLearnMethod.toMap(),
        "version_group": versionGroup.toMap(),
    };
}

class Sprites {
    final String backDefault;
    final dynamic backFemale;
    final String backShiny;
    final dynamic backShinyFemale;
    final String frontDefault;
    final dynamic frontFemale;
    final String frontShiny;
    final dynamic frontShinyFemale;

    Sprites({
        this.backDefault,
        this.backFemale,
        this.backShiny,
        this.backShinyFemale,
        this.frontDefault,
        this.frontFemale,
        this.frontShiny,
        this.frontShinyFemale,
    });

    Sprites copyWith({
        String backDefault,
        dynamic backFemale,
        String backShiny,
        dynamic backShinyFemale,
        String frontDefault,
        dynamic frontFemale,
        String frontShiny,
        dynamic frontShinyFemale,
    }) => 
        Sprites(
            backDefault: backDefault ?? this.backDefault,
            backFemale: backFemale ?? this.backFemale,
            backShiny: backShiny ?? this.backShiny,
            backShinyFemale: backShinyFemale ?? this.backShinyFemale,
            frontDefault: frontDefault ?? this.frontDefault,
            frontFemale: frontFemale ?? this.frontFemale,
            frontShiny: frontShiny ?? this.frontShiny,
            frontShinyFemale: frontShinyFemale ?? this.frontShinyFemale,
        );

    factory Sprites.fromJson(String str) => Sprites.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Sprites.fromMap(Map<String, dynamic> json) => Sprites(
        backDefault: json["back_default"],
        backFemale: json["back_female"],
        backShiny: json["back_shiny"],
        backShinyFemale: json["back_shiny_female"],
        frontDefault: json["front_default"],
        frontFemale: json["front_female"],
        frontShiny: json["front_shiny"],
        frontShinyFemale: json["front_shiny_female"],
    );

    Map<String, dynamic> toMap() => {
        "back_default": backDefault,
        "back_female": backFemale,
        "back_shiny": backShiny,
        "back_shiny_female": backShinyFemale,
        "front_default": frontDefault,
        "front_female": frontFemale,
        "front_shiny": frontShiny,
        "front_shiny_female": frontShinyFemale,
    };
}

class Stat {
    final int baseStat;
    final int effort;
    final Species stat;

    Stat({
        this.baseStat,
        this.effort,
        this.stat,
    });

    Stat copyWith({
        int baseStat,
        int effort,
        Species stat,
    }) => 
        Stat(
            baseStat: baseStat ?? this.baseStat,
            effort: effort ?? this.effort,
            stat: stat ?? this.stat,
        );

    factory Stat.fromJson(String str) => Stat.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Stat.fromMap(Map<String, dynamic> json) => Stat(
        baseStat: json["base_stat"],
        effort: json["effort"],
        stat: Species.fromMap(json["stat"]),
    );

    Map<String, dynamic> toMap() => {
        "base_stat": baseStat,
        "effort": effort,
        "stat": stat.toMap(),
    };
}

class Type {
    final int slot;
    final Species type;

    Type({
        this.slot,
        this.type,
    });

    Type copyWith({
        int slot,
        Species type,
    }) => 
        Type(
            slot: slot ?? this.slot,
            type: type ?? this.type,
        );

    factory Type.fromJson(String str) => Type.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Type.fromMap(Map<String, dynamic> json) => Type(
        slot: json["slot"],
        type: Species.fromMap(json["type"]),
    );

    Map<String, dynamic> toMap() => {
        "slot": slot,
        "type": type.toMap(),
    };
}
