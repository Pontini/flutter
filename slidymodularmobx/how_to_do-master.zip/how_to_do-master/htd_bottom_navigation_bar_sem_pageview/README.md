# how_to_do_bottom_navigation_bar_sem_pageview

A new Flutter project.

<img src="https://github.com/Bwolfs2/how_to_do/blob/master/htd_bottom_navigation_bar_sem_pageview/bottom_navigations.PNG" width="300">
