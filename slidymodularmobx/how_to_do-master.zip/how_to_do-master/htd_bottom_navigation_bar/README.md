# how_to_do_bottom_navigation_bar

A new Flutter project.

<img src="https://github.com/Bwolfs2/how_to_do/blob/master/htd_bottom_navigation_bar/bottom_navigations.PNG" width="300">


